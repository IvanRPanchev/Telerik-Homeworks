﻿//Problem 11. Bank Account Data

//A bank account has a holder name (first name, middle name and last name), available amount of money (balance), bank name, IBAN, 3 credit card numbers associated with the account.
//Declare the variables needed to keep the information for a single bank account using the appropriate data types and descriptive names.
using System;

class BankAccount
{
    static void Main()
    {
        string holderFirstName;
        string holderMiddleName;
        string holderLastName;
        decimal balance;
        string bankName;
        string IBAN;
        long creditCardNumber1;
        long creditCardNumber2;
        long creditCardNumber3;

        holderFirstName = "XXXX";
        holderMiddleName = "YYYY";
        holderLastName = "ZZZZ";
        balance = 666;
        bankName = "KTB :("; //:D
        IBAN = "BG85STSA12345678912345";
        creditCardNumber1 = 6776030078884332;
        creditCardNumber2 = 1293129091298001;
        creditCardNumber3 = 1209839102309111;
        Console.WriteLine("{0} {1} {2}\n{3}\n{4}\n{5}\n{6}\n{7}\n{8}", holderFirstName, holderMiddleName, holderLastName, balance, bankName, IBAN, creditCardNumber1, creditCardNumber2, creditCardNumber3);

    }
}

