﻿//Problem 12. Null Values Arithmetic

//Create a program that assigns null values to an integer and to a double variable.
//Try to print these variables at the console.
//Try to add some number or the null literal to these variables and print the result.
using System;
class NullValue
{
    static void Main()
    {
        int? a = null;
        double? b = null;
 
        Console.WriteLine("Printing the nullable variables: a: {0} b: {1}", a, b);
 
        a += null;
        b += 666;
        Console.WriteLine("Printing the nullable variables: a: {0} b: {1}", a, b);
    }

}

