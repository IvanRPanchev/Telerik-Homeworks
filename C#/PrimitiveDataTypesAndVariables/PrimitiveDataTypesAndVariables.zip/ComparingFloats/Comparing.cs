﻿//Problem 13.* Comparing Floats

//Write a program that safely compares floating-point numbers (double) with precision eps = 0.000001.
using System;
class Comparing
{
    static void Main()
    {
        Console.Write("Enter first number : ");
        double firstNumber = double.Parse(Console.ReadLine());

        Console.Write("Enter second number : ");
        double secondNumber = double.Parse(Console.ReadLine());

        double difference = Math.Abs(firstNumber - secondNumber);

        double precision = 0.000001;
        bool areEqual = difference < precision;

        Console.WriteLine(areEqual);
    }
}
