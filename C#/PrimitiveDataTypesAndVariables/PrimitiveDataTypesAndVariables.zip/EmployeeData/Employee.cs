﻿//Problem 10. Employee Data

//A marketing company wants to keep record of its employees. Each record would have the following characteristics:

//First name
//Last name
//Age (0...100)
//Gender (m or f)
//Personal ID number (e.g. 8306112507)
//Unique employee number (27560000…27569999)
//Declare the variables needed to keep the information for a single employee using appropriate primitive data types. Use descriptive names. Print the data at the console.
using System;
class Employee
{
    static void Main()
    {
        string FirstName;
        string LastName;
        byte Age;
        char Gender;
        ulong PersonalIDNumber;
        uint UniqueEmployeeNumber;
        FirstName = "XXXX";
        LastName = "YYYY";
        Age = 25;
        Gender = 'm';
        PersonalIDNumber = 8306112507;
        UniqueEmployeeNumber = 27560666;
        Console.WriteLine("{0}\n{1}\n{2}\n{3}\n{4}\n{5}", FirstName, LastName, Age, Gender, PersonalIDNumber, UniqueEmployeeNumber);
    }
}

